#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a=10, b=20, c=30;
    cout<<"\na="<<a;
    cout<<"\nb="<<b;
    cout<<"\nc="<<c;
    getch();
}