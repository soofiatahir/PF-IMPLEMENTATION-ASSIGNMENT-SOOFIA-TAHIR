#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    float a=2.5, km, mile;
    mile=1.609;    //1 mile=1.609 kilometers 
    km=a*mile;
    cout<<"2.5 miles="<<km<<" km";
    getch();
}
