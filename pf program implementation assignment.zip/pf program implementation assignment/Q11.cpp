#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a=23, b=26;
    float avg;
    avg=(a+b)/2.0;
    cout<<"Average="<<avg;
    getch();
}