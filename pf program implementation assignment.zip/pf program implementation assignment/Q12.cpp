#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    float R, H, Volume;
    const float π=3.1417;
    cout<<"Enter the Radius=";
    cin>>R;
    cout<<"Enter the Height=";
    cin>>H;
    Volume =(π)*(R*R)*(H);
    cout<<"Volume="<<Volume;
    getch();
}