#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    float R, area;
    const float π=3.1417;
    
    cout<<"Enter radius of the circle=";
    cin>>R;
    area=(π)*(R*R);
    cout<<"Area of the circle="<<area;
    getch();
}