#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    float a, milimeters_to_inches;
    const float inch=25.4;
    cout<<"Enter number in milimeters=";
    cin>>a;
    milimeters_to_inches=a/inch;
    cout<<"Milimeters to inches="<<milimeters_to_inches<<" inches";
    getch();
}