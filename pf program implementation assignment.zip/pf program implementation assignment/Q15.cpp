#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a, b, temp;
    cout<<"\nEnter variables one=";
    cin>>a;
    cout<<"Enter variable two=";
    cin>>b;
    cout<<"----Variables before interchange----";
    cout<<"\nVariable 1="<<a;
    cout<<"\nVariable two="<<b;
    temp=a;
    a=b;
    b=temp;
    cout<<"\n----Variables after interchange----";
    cout<<"\nVariable one="<<a;
    cout<<"\nVariable two="<<b;
    getch();
}