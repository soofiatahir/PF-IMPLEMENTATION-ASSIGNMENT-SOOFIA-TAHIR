#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a, b, c, product;
    a=b=c=3;
    product=a*b*c;
    cout<<"Product="<<product;
    getch();
}