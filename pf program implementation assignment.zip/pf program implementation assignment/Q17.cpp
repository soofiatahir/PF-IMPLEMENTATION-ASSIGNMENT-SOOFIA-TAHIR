#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int real_number;
	float a, fractional_part;
	a=15.58971;
	real_number=int(a);
	fractional_part=(a)-real_number;
	cout<<"the real part of 15.58971="<< real_number;
	cout<<"\nthe fractional part of 15.58971="<< fractional_part;
	getch();
}