#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    float vi, t, a, S;
    vi=5;
    t=6;
    a=2;
    S=(vi*t)+(0.5*a*t*t);
    cout<<"Distance="<<S;
    getch();
}