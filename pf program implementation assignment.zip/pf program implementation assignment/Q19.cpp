#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int age, age_in_months, age_in_days;        
    cout<<"Enter age=";
    cin>>age;
    age_in_months=age*12;         
    age_in_days=age*365;        
    cout<<"Your age in months="<<age_in_months<<" months";
    cout<<"\nYour age in days="<<age_in_days<<"  days";
    getch();
}