#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    cout<<"\nC++ is a powerful language.";
    getch();
}