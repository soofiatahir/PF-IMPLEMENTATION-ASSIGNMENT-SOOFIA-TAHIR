#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    cout<<"C:\\Windows>";
    cout<<"\n'P'     'A'     'K'";
	cout<<"\n\"Pakistan\"";
	getch();
}