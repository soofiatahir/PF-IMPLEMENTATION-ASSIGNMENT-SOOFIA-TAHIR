#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    string name, gender;
    int age;
    float height;
    cout<<"Enter Name=";
    getline(cin, name);
    cout<<"Enter Gender=";
    getline(cin, gender);
    cout<<"Enter Age=";
    cin>>age;
    cout<<"Enter Height=";
    cin>>height;
    cout<<"----Student Data----"<<endl;
    cout<<"Name="<<name<<endl;
    cout<<"Age="<<age<<endl;
    cout<<"Height="<<height<<endl;
    cout<<"Gender="<<gender<<endl;
    getch();
}