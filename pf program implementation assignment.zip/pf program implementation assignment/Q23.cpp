#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    float area, circumference, R;
    const float π=3.1417;
    cout<<"Enter Radius of the circle=";
    cin>>R;
    area=(π*R*R);
    circumference=(2*π*R);
    cout<<"\nArea of the circle="<<area;
    cout<<"\nCircumference of the circle="<<circumference;
    getch();
}