#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int subject1, subject2, subject3, subject4, subject5, total;
    float avg;
    cout<<"Enter marks obtained in subject1=";
    cin>>subject1;
    cout<<"Enter marks obtained in subject2=";
    cin>>subject2; 
    cout<<"Enter marks obtained in subject3=";
    cin>>subject3;
    cout<<"Enter marks obtained in subject4=";
    cin>>subject4;
    cout<<"Enter marks obtained in subject5=";
    cin>>subject5;
    total=subject1+subject2+subject3+subject4+subject5;
    avg=total/5.0;
    cout<<"Total obtained marks="<<total;
    cout<<"\nAverage="<<avg;
    getch();
}