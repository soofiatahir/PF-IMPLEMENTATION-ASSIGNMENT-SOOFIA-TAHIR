#include<iostream>
#include<conio.h>
using namespace std;
#include<math.h>
int main()
{
    int a, b, c;
    float s, area;
    cout<<"Enter value of a=";
    cin>>a;
    cout<<"Enter value of b=";
    cin>>b;
    cout<<"Enter value of c=";
    cin>>c;
    s=(a+b+c)/2.0;
    area=sqrt((s*(s-a)*(s-b)*(s-c)));
    cout<<"Area="<<area;
    getch();
}