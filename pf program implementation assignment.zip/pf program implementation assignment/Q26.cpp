#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int rupee, dollar_rate, rupee_to_dollar;
    rupee=12000;
    dollar_rate=60;         
    rupee_to_dollar=rupee/dollar_rate;
    cout<<"12000 rupees to dollars="<<rupee_to_dollar<<"dollars";
    getch();
}