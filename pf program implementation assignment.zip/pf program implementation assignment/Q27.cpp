#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
   int a, b, c, hours_in_seconds, minutes_in_seconds, seconds, result;
   cout<<"Enter time in hours=";
   cin>>a;
   cout<<"Enter time in minutes=";
   cin>>b;
   cout<<"Enter time in seconds=";
   cin>>c;
   hours_in_seconds=(a*3600);
   minutes_in_seconds=(b*60);
   seconds=c;
   result=(hours_in_seconds)+(minutes_in_seconds)+(seconds);
   cout<<"time in seconds="<<result<<"seconds";
   getch();
}