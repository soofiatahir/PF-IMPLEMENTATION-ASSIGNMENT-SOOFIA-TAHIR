#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    float a, b, c, disc;
    cout<<"Enter value of a=";
    cin>>a;
    cout<<"Enter value of b=";
    cin>>b;
    cout<<"Enter value of c=";
    cin>>c;
    disc = (b*b)-(4.0*a*c);
    cout<<"discriminant="<< disc;
    getch();
}