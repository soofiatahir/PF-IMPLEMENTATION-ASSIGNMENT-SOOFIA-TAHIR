#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int n;
    cout<<"Enter a number=";
    cin>>n;
    if(n>100)
    {
        cout<<n<<"is greater than 100"<<endl;
    }
    getch();
}