#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a=1, b=2, temp;
    cout<<"Before swapping";
    cout<<"\na="<<a;
    cout<<"\nb="<<b;
    temp=a;
    a=b;
    b=temp;
    cout<<"\nAfter swapping";
    cout<<"\na="<<a;
    cout<<"\nb="<<b;
    getch();
}