#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int year=20, nom;
    nom=year*12;         //nom=number of months
    cout<<"\nNumber of months in 20 years="<<nom<<" months";
    getch();
}