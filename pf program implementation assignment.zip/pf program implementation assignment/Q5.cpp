#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a, b, sum, prod;
    cout<<"Enter first number=";
    cin>>a;
    cout<<"\nEnter second number=";
    cin>>b;
    sum=a+b;
    prod=a*b;
    cout<<"\nSum="<<sum;
    cout<<"\nProduct="<<prod;
    getch();
}