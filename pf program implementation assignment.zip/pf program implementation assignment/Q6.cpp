#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int age, ain;           //ain= age in month
    cout<<"Enter Age=";
    cin>>age;
    ain=age*12;
    cout<<"\nYour Age in Month="<<ain<<" months";
    getch();
}