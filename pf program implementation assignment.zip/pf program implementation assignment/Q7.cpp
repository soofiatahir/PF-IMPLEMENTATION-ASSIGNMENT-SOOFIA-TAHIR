#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int roll_number, a, b, c, total, total_marks;
    float avg;
    cout<<"Enter your roll number=";
    cin>>roll_number;
    cout<<"\nEnter marks obtained in programming fundamental=";
    cin>>a;
    cout<<"\nEnter marks obtained in introduction to computing=";
    cin>>b;
    cout<<"\nEnter marks obtained in computer graphics=";
    cin>>c;
    total_marks=300;    //maximum marks of each subject are 100
    total=a+b+c;
    avg=(a+b+c)/3.0;
    cout<<"\nTotal obtained marks="<<total<<" out of 300";
    cout<<"\nAverage="<<avg;
    getch();
}