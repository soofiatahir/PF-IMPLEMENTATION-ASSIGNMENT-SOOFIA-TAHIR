#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    float C, f;
    cout<<"Enter temperature in fahrenheit=";
    cin>>f;
    C=(5.0/9.0)*(f-32);
    cout<<"Temperature in Celcius="<<C<<" Celcius";
    getch();
}