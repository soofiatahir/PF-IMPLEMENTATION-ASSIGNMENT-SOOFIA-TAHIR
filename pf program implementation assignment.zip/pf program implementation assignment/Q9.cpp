#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int num, num1, num2, num3, num4;
    cout<<"Enter number 1=";
    cin>>num1;
    cout<<"Enter number 2=";
    cin>>num2;
    cout<<"Enter number 3=";
    cin>>num3;
    cout<<"Enter number 4=";
    cin>>num4;
    num=num1;
    if(num2>num)
    {
        num=num2;
    }
    if(num3>num)
    {
       num=num3;
    }
    if(num4>num)
    {
        num=num4;
    }
    cout<<num<<" is greatest number.";
getch();
}
    
    
    
    
    